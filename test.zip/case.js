const fs = require('fs'),
    chalk = require('chalk'),
    util = require('util'),
    path = require('path'),
    crypto = require('crypto'),
    moment = require('moment-timezone'),
    phonenumber = require('awesome-phonenumber'),
    baileys = require('@whiskeysockets/baileys'),
    toMs = require('ms'),
    yts = require('yt-search'),
    ytdl = require('ytdl-core'),
    axios = require('axios'),
    cheerio = require('cheerio'),
    request = require('request'),
    ms = require('parse-ms'),
    fetch = require('node-fetch');
const {
    exec
} = require('child_process');
const func = require('./system/functions.js');

module.exports = async (m, mecha, extra) => {
    const {
        chat, sender, body, budy, prefix, command, cmd, args, text, mtype, reply, expiration, isDevs, isOwner, isPrem, isVIP, isPrefix, isBot, isPc, isGc, isAdmin, isBotAdmin
    } = m;
    const {
        plugins, commands, events, store, users, groups, setting, date, time, packname, author, isBanned, quoted, mime, froms, errorMessage, YT, CASE, lid
    } = extra;

    function get(jid) {
        if (jid.endsWith('@g.us')) {
            return global.db.groups[jid]
        } else {
            jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
            return global.db.users[jid]
        }
    }

    let target;
    if (froms) {
        target = global.db.users[froms];
    }

    // Memblokir command dari baileys
    if (isBot) return
    // Memblokir command yang sudah ada pada plugins
    if (command && commands.includes(command)) return
    // Feature Versi Case
    switch (command) {
        case 'p':
            mecha.sendMessageModify(chat, `Quick Test Done! ${m.pushname}`, m, {
                title: 'Aktif Selama :',
                body: func.runtime(process.uptime()),
                thumbUrl: setting.cover,
                largeThumb: false,
                url: null,
                expiration
            })
            break
        default:
            // EVAL & EXEC CODE
            if (isDevs && /^(x|xx)$/.test(m.command)) {
                let evalCode;
                let evalCmd;
                if (m.command === 'x') evalCode = text ? text : false;
                else if (m.command === 'xx') evalCode = m.quoted && m.quoted.text ? m.quoted.text : text ? text : false
                if (!evalCode) return false;
                try {
                    evalCmd = /await/i.test(evalCode) ? eval("(async () => { " + evalCode + " })()") : eval(evalCode)
                    let evaled = await evalCmd;
                    if (typeof evaled !== 'string') evaled = util.inspect(evaled)
                    mecha.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (error) {
                    mecha.sendMessage(m.chat, {
                        text: util.format(error)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (isDevs && m.command === '=>' && text) {
                try {
                    let evaled = await eval(`(async () => { return ${text} })()`)
                    mecha.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (e) {
                    mecha.sendMessage(m.chat, {
                        text: util.format(e)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (isDevs && m.command === '$' && text) {
                mecha.sendReact(m.chat, '🕒', m.key)
                exec(text, (err, stdout) => {
                    if (err) return mecha.sendMessage(m.chat, {
                        text: err.toString()
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                    if (stdout) return mecha.sendMessage(m.chat, {
                        text: util.format(stdout)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                })
            }
    }
}

func.reloadFile(__filename)