exports.run = {
    usage: ['listcmd'],
    category: 'info',
    async: async (m, {
        mecha,
        setting
    }) => {
        const data = Object.entries(global.db.stickercmd)
        if (data.length == 0) return m.reply('*Empty data.*')
        let caption = `乂  *LIST STICKER CMD*\n`
        caption += data.map(([key, v], index) => `\n${index++}. ${v.text}\n◦  Creator: @${v.creator.split('@')[0]}\n◦  Key: ${key}`).join('\n')
        await m.reply(caption);
    },
    location: 'plugins/info/listcmd.js'
}