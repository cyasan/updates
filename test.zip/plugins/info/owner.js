exports.run = {
    usage: ['owner'],
    hidden: ['creator', 'developer', 'dev'],
    category: 'info',
    async: async (m, {
        func,
        mecha
    }) => {
        mecha.sendkontak(m.chat, global.owner, global.ownerName, m)
    },
    location: 'plugins/info/owner.js'
}