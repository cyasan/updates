exports.run = {
    usage: ['listbadword'],
    category: 'info',
    async: async (m, {
        mecha,
        setting
    }) => {
        if (setting.toxic.length == 0) return m.reply('Empty data.')
        let caption = `乂  *LIST BAD WORD*\n\nTotal : ${setting.toxic.length}\n`
        caption += setting.toxic.map((v, i) => `${i + 1}. ${v}`).join('\n')
        mecha.reply(m.chat, caption, m)
    },
    location: 'plugins/info/listbadword.js'
}