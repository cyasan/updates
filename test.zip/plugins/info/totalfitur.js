exports.run = {
    usage: ['totalfitur'],
    hidden: ['fitur'],
    category: 'info',
    async: async (m, {
        func,
        mecha,
        plugins
    }) => {
        const categories = {};

        // Mengelompokkan fitur berdasarkan kategori
        Object.entries(plugins).forEach(([_, plugin]) => {
            const {
                run
            } = plugin;
            if (run && run.usage && run.category) {
                const category = run.category.toLowerCase();
                if (!categories[category]) {
                    categories[category] = [];
                }
                categories[category].push(run);
            }
        });

        // Membuat caption
        let caption = '乂 *F E A T U R E - L I S T*\n';
        const sortedKeys = Object.keys(categories).sort();

        sortedKeys.forEach(key => {
            const commands = categories[key].flatMap(run =>
                Array.isArray(run.usage) ? run.usage : [run.usage]
            ).sort((a, b) => a.localeCompare(b));

            caption += `\n◦ ${func.ucword(key)} : ${commands.length} feature`;
        });

        caption += `\n\n*Total Plugins : ${Object.keys(plugins).length}*`;
        caption += `\n*Total Feature : ${func.totalFeature(plugins)} Commands*`;

        mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        });
    },
    location: 'plugins/info/totalfitur.js'
}