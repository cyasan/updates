exports.run = {
    usage: 'listsewa',
    category: 'info',
    async: async (m, {
        func,
        mecha
    }) => {
        const data = Object.values(global.db.groups).filter(x => x.sewa.status && !isNaN(x.sewa.expired))
        if (data.length == 0) return m.reply('*Empty data.*')
        let caption = '乂  *L I S T  S E W A*\n'
        caption += data.map((v, i) => `\n${i + 1}. ${global.db.metadata[v.jid]?.subject || v.name}\n◦  ID: ${v.jid}\n◦  VIP: ${v.sewa?.vip ? '✅' : '❌'}\n◦  Expire: ${v.sewa.expired === 'PERMANENT' ? 'PERMANENT' : func.expireTime(v.sewa.expired)}`).join('\n')
        mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        })
    },
    location: 'plugins/info/listsewa.js'
}