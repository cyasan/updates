const fetch = require('node-fetch')

exports.run = {
    usage: ['status'],
    category: 'info',
    async: async (m, {
        func,
        mecha
    }) => {
        const caption = await fetch(`http://ip-api.com/line`)
            .then(res => res.text());
        await m.reply(caption);
    },
    location: 'plugins/info/status.js'
}