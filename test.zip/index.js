/*
 * Nama Pengembang: SuryaDev.
 * Kontak Whatsapp: wa.me/62895415497664
 * Kontak Telegram: t.me/suryadev05
 * Akun Instagram: surya_skylark05
 * Catatan: tolong laporkan kepada saya jika anda menemukan ada yang menjual script ini tanpa seizin saya.
 */

const {
    spawn
} = require('child_process');
const fs = require('fs');
const path = require('path');

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0'

const unhandledRejections = new Map()
process.on('unhandledRejection', (reason, promise) => {
    unhandledRejections.set(promise, reason)
    console.log('Unhandled Rejection at:', promise, 'reason:', reason)
})
process.on('rejectionHandled', (promise) => {
    unhandledRejections.delete(promise)
})
process.on('Something went wrong', function(err) {
    console.log('Caught exception: ', err)
})

function updateFileBaileys(){var s=fs.readFileSync("./lib/groups.js","utf-8"),i="./node_modules/@whiskeysockets/baileys/lib/Socket/groups.js";fs.writeFileSync(i,s),console.log(`Sukses Update File “${i}“`)}

function start() {
    updateFileBaileys();
    let args = [path.join(__dirname, 'connect.js'), ...process.argv.slice(2)]
    let p = spawn(process.argv[0], args, {
            stdio: ['inherit', 'inherit', 'inherit', 'ipc']
        })
        .on('message', data => {
            if (data == 'reset') {
                console.log('Restarting...')
                p.kill()
                delete p
            }
        })
        .on('exit', code => {
            console.error('Exited with code:', code)
            start()
        })
}

start();